clc
clear all
syms x1 x2 x3 x4 x5 x6 L3 L4 L5 SH2 SH3 a b
 x1=0;
 x2=0;
 x3=0;
 x4=0;
 x5=0;
 x6=pi/4;
 L3=6.00;
 L4=5.5;
 L5=1.0;
 SH2=1.35;
 SH3=1.25;
 a=0.5;
 b=sqrt(3)/2;
% x1=2;
% x2=2;
% x3=2;
% x4=0;
% x5=0;
% x6=pi/4;
Jw1=[0;0;1];
Jw2=[sin(x1);-cos(x1);0];
Jw3=[-sin(x1);cos(x1);0];
Jw4=[cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3);cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3);cos(x3)*sin(x2) - cos(x2)*sin(x3)];
Jw5=[a*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3)) - b*(sin(x1)*sin(x4) + cos(x4)*(cos(x1)*cos(x2)*sin(x3) - cos(x1)*cos(x3)*sin(x2)));a*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3)) + b*(cos(x1)*sin(x4) - cos(x4)*(cos(x2)*sin(x1)*sin(x3) - cos(x3)*sin(x1)*sin(x2)));- a*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) - b*cos(x4)*(cos(x2)*cos(x3) + sin(x2)*sin(x3))];
Jw6=[a*(a*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3)) - b*(sin(x1)*sin(x4) + cos(x4)*(cos(x1)*cos(x2)*sin(x3) - cos(x1)*cos(x3)*sin(x2)))) + b*(sin(x5)*(cos(x4)*sin(x1) - sin(x4)*(cos(x1)*cos(x2)*sin(x3) - cos(x1)*cos(x3)*sin(x2))) + a*cos(x5)*(sin(x1)*sin(x4) + cos(x4)*(cos(x1)*cos(x2)*sin(x3) - cos(x1)*cos(x3)*sin(x2))) + b*cos(x5)*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3)));a*(a*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3)) + b*(cos(x1)*sin(x4) - cos(x4)*(cos(x2)*sin(x1)*sin(x3) - cos(x3)*sin(x1)*sin(x2)))) - b*(sin(x5)*(cos(x1)*cos(x4) + sin(x4)*(cos(x2)*sin(x1)*sin(x3) - cos(x3)*sin(x1)*sin(x2))) + a*cos(x5)*(cos(x1)*sin(x4) - cos(x4)*(cos(x2)*sin(x1)*sin(x3) - cos(x3)*sin(x1)*sin(x2))) - b*cos(x5)*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3)));- b*(sin(x4)*sin(x5)*(cos(x2)*cos(x3) + sin(x2)*sin(x3)) + b*cos(x5)*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) - a*cos(x4)*cos(x5)*(cos(x2)*cos(x3) + sin(x2)*sin(x3))) - a*(a*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) + b*cos(x4)*(cos(x2)*cos(x3) + sin(x2)*sin(x3)))];
Jw=[Jw1 Jw2 Jw3 Jw4 Jw5 Jw6]

T60(1,4)=SH2*cos(x1) + L4*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3)) - L5*b*(sin(x1)*sin(x4) + cos(x4)*(cos(x1)*cos(x2)*sin(x3) - cos(x1)*cos(x3)*sin(x2))) - cos(x1)*sin(x2)*(L3 + SH3) + L5*a*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3));
T60(2,4)= SH2*sin(x1) + L4*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3)) + L5*b*(cos(x1)*sin(x4) - cos(x4)*(cos(x2)*sin(x1)*sin(x3) - cos(x3)*sin(x1)*sin(x2))) - sin(x1)*sin(x2)*(L3 + SH3) + L5*a*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3));
T60(3,4)=cos(x2)*(L3 + SH3) - L4*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) - L5*a*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) - L5*b*cos(x4)*(cos(x2)*cos(x3) + sin(x2)*sin(x3));
Oe=[T60(1,4);T60(2,4);T60(3,4)];
O1=[0; 0 ; 0];
O2=[SH2*cos(x1);SH2*sin(x1);0];
O3=[SH2*cos(x1) - cos(x1)*sin(x2)*(L3 + SH3);SH2*sin(x1) - sin(x1)*sin(x2)*(L3 + SH3);cos(x2)*(L3 + SH3)];
O4=[SH2*cos(x1) + L4*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3)) - cos(x1)*sin(x2)*(L3 + SH3);SH2*sin(x1) + L4*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3)) - sin(x1)*sin(x2)*(L3 + SH3);cos(x2)*(L3 + SH3) - L4*(cos(x2)*sin(x3) - cos(x3)*sin(x2))];
O5=[SH2*cos(x1) + L4*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3)) - L5*b*(sin(x1)*sin(x4) + cos(x4)*(cos(x1)*cos(x2)*sin(x3) - cos(x1)*cos(x3)*sin(x2))) - cos(x1)*sin(x2)*(L3 + SH3) + L5*a*(cos(x1)*cos(x2)*cos(x3) + cos(x1)*sin(x2)*sin(x3));SH2*sin(x1) + L4*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3)) + L5*b*(cos(x1)*sin(x4) - cos(x4)*(cos(x2)*sin(x1)*sin(x3) - cos(x3)*sin(x1)*sin(x2))) - sin(x1)*sin(x2)*(L3 + SH3) + L5*a*(cos(x2)*cos(x3)*sin(x1) + sin(x1)*sin(x2)*sin(x3));cos(x2)*(L3 + SH3) - L4*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) - L5*a*(cos(x2)*sin(x3) - cos(x3)*sin(x2)) - L5*b*cos(x4)*(cos(x2)*cos(x3) + sin(x2)*sin(x3))];
Jv1=cross(Jw1,(Oe-O1));
Jv2=cross(Jw2,(Oe-O2));
Jv3=cross(Jw3,(Oe-O3));
Jv4=cross(Jw4,(Oe-O4));
Jv5=cross(Jw5,(Oe-O5));
Jv6=[0; 0; 0];
% theta = [x1 x2 x3 x4 x5 x6];
% assume(theta,'real');


Jv=[Jv1,Jv2,Jv3,Jv4,Jv5,Jv6]

J=[Jv;Jw]

determinant=det(J)
