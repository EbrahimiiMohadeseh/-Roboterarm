clear
clc
close all
%% DH parameters and dimentions
l1 = 1.35; 
l2 = 7.25; 
l3 = 5.5; 
l4 = 1; 
l5 = 0; 
l6 = 0;
n = 6;
alpha = [0 90 180 90 60 60];
a = [0 1.35 7.25 0 0 0];
d = [0 0 0 5.5 1 0];
theta = 0;
for i = 1:6
        t = input(sprintf('input theta%d: ',i));
        theta(i) = t;
end

%% Forward Kinematics
T = [];
for i = 1:n
    T(:,:,i) = [cosd(theta(i)),-sind(theta(i)),0,a(i);...
           sind(theta(i))*cosd(alpha(i)),cosd(theta(i))*cosd(alpha(i)),-sind(alpha(i)),-sind(alpha(i))*d(i);...
           sind(theta(i))*sind(alpha(i)),cosd(theta(i))*sind(alpha(i)),cosd(alpha(i)),cosd(alpha(i))*d(i);...
           0,0,0,1];
end
x=[0];
y=[0];
z=[0];
T_final = eye(4);
for i = 1:6
    T_final = T_final*T(:,:,i);
       x(i+1)=T_final(1,4);
       y(i+1)=T_final(2,4);
       z(i+1)=T_final(3,4);
end
%% plot
figure
plot3(x,y,z,'-o','Color','b','MarkerSize',10,'MarkerFaceColor','#D9FFFF')
xlabel('x');
ylabel('y');
zlabel('z');
grid on
