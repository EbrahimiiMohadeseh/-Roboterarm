clear all
clc
%s1 & c1 stand for sin(theta1) & cos(theta1) recpectively
%a & b stand for cos(60) and sin(60) recpectively

syms s1 c1 s2 c2 s3 c3 s4 c4 s5 c5 s6 c6 L3 L4 L5 SH2 SH3 a b

T10=[c1 -s1 0 0;s1 c1 0 0;0 0 1 0;0 0 0 1];

T21=[-s2 -c2 0 SH2;0 0 -1 0;c2 -s2 0 0;0 0 0 1];

T32=[-c3 s3 0 L3+SH3;s3 c3 0 0;0 0 -1 0;0 0 0 1];

T43=[-s4 -c4 0 0;0 0 -1 -L4;c4 -s4 0 0;0 0 0 1];

T54=[-c5 s5 0 0;-a*s5 -a*c5 -b -L5*b;-b*s5 -b*c5 a L5*a;0 0 0 1];

T65=[c6 -s6 0 0;a*s6 a*c6 -b 0;b*s6 b*c6 a 0;0 0 0 1];

% transformation matrix 

T60=T10*T21*T32*T43*T54*T65
