clear all
clc
i=1;

a=zeros();
n=input('How many rows do you have in your DH parameters table?\n')
for i=1:n

a(i)=input('please enter your link length(in cm) recpectively\n');
i=i+1;

end
i=1;
for i=1:n

alpha(i)=input("please enter your link twist (in degree) recpectively\n");
i=i+1;
end
i=1;
for i=1:n

d(i)=input("please enter your link offset(\d_i) recpectively\n");


i=i+1;

end
i=1;
for i=1:n

theta(i)=input('please enter your joint angle(\theta) (in egree) recpectively\n');


i=i+1;

end
i=1;
for i=1:n
T(:,:,i)=[1 0 0 0;0 cosd(alpha(i)) -sind(alpha(i)) 0;0 sind(alpha(i)) cosd(alpha(i)) 0;0 0 0 1]*[1 0  0 a(i);0 1 0 0 ;0 0 1 0;0 0 0 1]*[cosd(theta(i)) -sind(theta(i)) 0 0;sind(theta(i)) cosd(theta(i)) 0 0;0 0 1 0;0 0 0 1]*[1 0 0 0;0 1 0 0;0 0 1 d(i);0 0 0 1];
i=i+1;
end
i=n;
trans(:,:,i)=T(:,:,i);

for j=1:n
if i~=1
   trans(:,:,n)=T(:,:,i-1)*trans(:,:,n);
    i=i-1;
end
j=j+1;
end
TRANSFORMATION=trans(:,:,n)

