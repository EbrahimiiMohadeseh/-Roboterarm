%forward kinematics
format short
clear all
clc
a=0.5;
b=sqrt(3)/2;

%giving theta (x)
%HERE EXCEPT THETA FOR SIMPIFYING WE DEFINITE X 
 x6=0;
 s6=sin(x6);
 c6=cos(x6);
 x5=0;
 s5=sin(x5);
 c5=cos(x5);
 x4=0;
 s4=sin(x4);
 c4=cos(x4);
 x3=0;
 s3=sin(x3);
 c3=cos(x3);
 x2=0;
 s2=sin(x2);
 c2=cos(x2);
 x1=pi/4;
 s1=sin(x1);
 c1=cos(x1);
 
 %length of the links and offsets
 L3=6.00;
 L4=5.5;
 L5=1.0;
 SH2=1.35;
 SH3=1.25;
 
 %the first row of transformation matrix
T60(1,1)=b*s6*(a*(c1*c2*c3 + c1*s2*s3) - b*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2))) - a*s6*(s5*(c4*s1 - s4*(c1*c2*s3 - c1*c3*s2)) + a*c5*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) + b*c5*(c1*c2*c3 + c1*s2*s3)) - c6*(a*s5*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) - c5*(c4*s1 - s4*(c1*c2*s3 - c1*c3*s2)) + b*s5*(c1*c2*c3 + c1*s2*s3));
T60(1,2)=s6*(a*s5*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) - c5*(c4*s1 - s4*(c1*c2*s3 - c1*c3*s2)) + b*s5*(c1*c2*c3 + c1*s2*s3)) - a*c6*(s5*(c4*s1 - s4*(c1*c2*s3 - c1*c3*s2)) + a*c5*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) + b*c5*(c1*c2*c3 + c1*s2*s3)) + b*c6*(a*(c1*c2*c3 + c1*s2*s3) - b*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)));
T60(1,3)=a*(a*(c1*c2*c3 + c1*s2*s3) - b*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2))) + b*(s5*(c4*s1 - s4*(c1*c2*s3 - c1*c3*s2)) + a*c5*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) + b*c5*(c1*c2*c3 + c1*s2*s3));
T60(1,4)=SH2*c1 + L4*(c1*c2*c3 + c1*s2*s3) - L5*b*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) - c1*s2*(L3 + SH3) + L5*a*(c1*c2*c3 + c1*s2*s3);

%the second row of transformation matri
T60(2,1)=a*s6*(s5*(c1*c4 + s4*(c2*s1*s3 - c3*s1*s2)) + a*c5*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)) - b*c5*(c2*c3*s1 + s1*s2*s3)) - c6*(c5*(c1*c4 + s4*(c2*s1*s3 - c3*s1*s2)) - a*s5*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)) + b*s5*(c2*c3*s1 + s1*s2*s3)) + b*s6*(a*(c2*c3*s1 + s1*s2*s3) + b*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)));
T60(2,2)= s6*(c5*(c1*c4 + s4*(c2*s1*s3 - c3*s1*s2)) - a*s5*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)) + b*s5*(c2*c3*s1 + s1*s2*s3)) + a*c6*(s5*(c1*c4 + s4*(c2*s1*s3 - c3*s1*s2)) + a*c5*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)) - b*c5*(c2*c3*s1 + s1*s2*s3)) + b*c6*(a*(c2*c3*s1 + s1*s2*s3) + b*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)));
T60(2,3)= a*(a*(c2*c3*s1 + s1*s2*s3) + b*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2))) - b*(s5*(c1*c4 + s4*(c2*s1*s3 - c3*s1*s2)) + a*c5*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)) - b*c5*(c2*c3*s1 + s1*s2*s3));
T60(2,4)= SH2*s1 + L4*(c2*c3*s1 + s1*s2*s3) + L5*b*(c1*s4 - c4*(c2*s1*s3 - c3*s1*s2)) - s1*s2*(L3 + SH3) + L5*a*(c2*c3*s1 + s1*s2*s3);

%the third row of transformation matri
T60(3,1)= a*s6*(s4*s5*(c2*c3 + s2*s3) + b*c5*(c2*s3 - c3*s2) - a*c4*c5*(c2*c3 + s2*s3)) - b*s6*(a*(c2*s3 - c3*s2) + b*c4*(c2*c3 + s2*s3)) - c6*(c5*s4*(c2*c3 + s2*s3) - b*s5*(c2*s3 - c3*s2) + a*c4*s5*(c2*c3 + s2*s3));
T60(3,2)=s6*(c5*s4*(c2*c3 + s2*s3) - b*s5*(c2*s3 - c3*s2) + a*c4*s5*(c2*c3 + s2*s3)) + a*c6*(s4*s5*(c2*c3 + s2*s3) + b*c5*(c2*s3 - c3*s2) - a*c4*c5*(c2*c3 + s2*s3)) - b*c6*(a*(c2*s3 - c3*s2) + b*c4*(c2*c3 + s2*s3));
T60(3,3)= - b*(s4*s5*(c2*c3 + s2*s3) + b*c5*(c2*s3 - c3*s2) - a*c4*c5*(c2*c3 + s2*s3)) - a*(a*(c2*s3 - c3*s2) + b*c4*(c2*c3 + s2*s3));
T60(3,4)=c2*(L3 + SH3) - L4*(c2*s3 - c3*s2) - L5*a*(c2*s3 - c3*s2) - L5*b*c4*(c2*c3 + s2*s3);

%the fourth row of transformation matri
T60(4,1)=0;
T60(4,2)=0;
T60(4,3)=0;
T60(4,4)=1;

%%%%%Reachable Workspace%%%%%
x=zeros();
z=zeros();
x1=0;
j =1;
for x2=-80*pi/180:pi/40:130*pi/180 
    for x3=-75*pi/180:pi/30:pi/2
        for x4=-pi:pi/10:pi 
            for x5=-pi:pi/10:pi 
                   for x6 = -pi:pi/10:pi 
                   
      
 s6=sin(x6);
 c6=cos(x6);
 s5=sin(x5);
 c5=cos(x5);
 s4=sin(x4);
 c4=cos(x4);
 s3=sin(x3);
 c3=cos(x3);
 s2=sin(x2);
 c2=cos(x2);
 s1=sin(x1);
 c1=cos(x1);

         x(j) = SH2*c1 + L4*(c1*c2*c3 + c1*s2*s3) - L5*b*(s1*s4 + c4*(c1*c2*s3 - c1*c3*s2)) - c1*s2*(L3 + SH3) + L5*a*(c1*c2*c3 + c1*s2*s3);
         z(j) = c2*(L3 + SH3) - L4*(c2*s3 - c3*s2) - L5*a*(c2*s3 - c3*s2) - L5*b*c4*(c2*c3 + s2*s3);
        j = j+1;
                   end
            end
       end
    end
end

plot(x,z,"*",'linewidth',6);
grid on
axis('square')
